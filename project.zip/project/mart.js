let discount = 0;
let totalRevenue = 0;
let totalOrders = 0;
let totalFarmers = 0;

let paymentRecords = [];
let farmerRecords = [];



function addNotification(msg){

    let div = document.createElement("div");

    div.className = "notice";

    div.innerHTML =
    new Date().toLocaleTimeString() +
    " - " + msg;

    document
    .getElementById("notifications")
    .prepend(div);
}

addNotification("AgriConnect System Started");



function applyCoupon(){

    let code =
    document.getElementById("coupon").value;

    if(code === "AGRI10"){

        discount = 10;
        alert("10% Discount Applied");
    }

    else if(code === "AGRI20"){

        discount = 20;
        alert("20% Discount Applied");
    }

    else{

        alert("Invalid Coupon");
    }
}



function registerFarmer(){

    let farmer =
    document.getElementById("farmerName").value;

    let crop =
    document.getElementById("cropName").value;

    let quantity =
    document.getElementById("cropQuantity").value;

    if(!farmer || !crop || !quantity){

        alert("Fill all details");
        return;
    }

    let card =
    document.createElement("div");

    card.className =
    "farmer-card";

    card.innerHTML = `
    <h3>${farmer}</h3>
    Crop: ${crop}<br>
    Available: ${quantity} KG
    `;

    document
    .getElementById("farmersList")
    .prepend(card);

    farmerRecords.push({
        farmer,
        crop,
        quantity
    });

    totalFarmers++;

    document
    .getElementById("farmers")
    .innerHTML = totalFarmers;

    addNotification(
    farmer + " registered successfully"
    );

    alert("Farmer Registered Successfully!");
}



function placeOrder(){

    let customer =
    document.getElementById("customerName").value;

    let product =
    document.getElementById("product").value;

    let quantity =
    parseFloat(
    document.getElementById("quantity").value
    );

    let payment =
    document.getElementById("paymentMethod").value;

    if(
        !customer ||
        !product ||
        !quantity ||
        !payment
    ){

        alert("Please fill all details");
        return;
    }

    let pricePerKg = 0;

    switch(product){

        case "Wheat":
            pricePerKg = 30;
            break;

        case "Rice":
            pricePerKg = 40;
            break;

        case "Tomato":
            pricePerKg = 25;
            break;

        case "Potato":
            pricePerKg = 20;
            break;

        case "Onion":
            pricePerKg = 35;
            break;
    }

    let total =
    quantity * pricePerKg;

    if(discount > 0){

        total =
        total -
        (total * discount / 100);
    }

    document
    .getElementById("orderAmount")
    .innerHTML =
    "Total Amount: ₹" + total;

    totalRevenue += total;
    totalOrders++;

    document
    .getElementById("revenue")
    .innerHTML =
    "₹" + totalRevenue;

    document
    .getElementById("orders")
    .innerHTML =
    totalOrders;

    let order =
    document.createElement("div");

    order.className =
    "order-card";

    order.innerHTML = `
    <b>${customer}</b><br>
    Product: ${product}<br>
    Quantity: ${quantity} KG<br>
    Amount: ₹${total}<br>
    Payment: ${payment}<br>
    Status: Confirmed
    `;

    document
    .getElementById("orderHistory")
    .prepend(order);

    processPayment(
        product,
        total,
        payment
    );

    addNotification(
    product + " ordered successfully"
    );

    alert("🌾 Order Placed Successfully!");
}
function processPayment(
    product,
    amount,
    paymentMethod
){

    let payment = {

        id:
        "TXN" +
        Date.now(),

        product,

        amount,

        paymentMethod,

        date:
        new Date()
        .toLocaleString(),

        status:
        "Success"
    };

    paymentRecords.push(
    payment
    );

    document
    .getElementById(
    "paymentStatus"
    )
    .innerHTML =
    "✅ Payment Successful";

    updatePaymentHistory();

    savePayments();
}
function updatePaymentHistory(){

    const history =
    document.getElementById(
    "paymentHistory"
    );

    if(!history) return;

    history.innerHTML = "";

    paymentRecords
    .slice()
    .reverse()
    .forEach(payment => {

        history.innerHTML += `
        <div class="payment-card">

        <b>Transaction:</b>
        ${payment.id}<br>

        <b>Product:</b>
        ${payment.product}<br>

        <b>Amount:</b>
        ₹${payment.amount}<br>

        <b>Method:</b>
        ${payment.paymentMethod}<br>

        <b>Status:</b>
        ${payment.status}<br>

        <b>Date:</b>
        ${payment.date}

        </div>
        `;
    });
}
function savePayments(){

    localStorage.setItem(
    "payments",
    JSON.stringify(paymentRecords)
    );
}
function loadPayments(){

    const data =
    localStorage.getItem(
    "payments"
    );

    if(data){

        paymentRecords =
        JSON.parse(data);

        updatePaymentHistory();
    }
}

loadPayments();



function submitReview(){

    let name =
    document.getElementById("reviewName").value;

    let rating =
    document.getElementById("reviewRating").value;

    let text =
    document.getElementById("reviewText").value;

    if(
        !name ||
        !rating ||
        !text
    ){
        alert(
        "Please enter review details"
        );
        return;
    }

    let review =
    document.createElement("div");

    review.className =
    "review-card";

    review.innerHTML = `
    <b>${name}</b><br>
    ⭐ ${rating}<br>
    ${text}
    `;

    document
    .getElementById("reviews")
    .prepend(review);

    addNotification(
    "New Product Review Added"
    );

    alert("Review Submitted!");
}
function sendMessage(){

    let name =
    document.getElementById(
    "contactName"
    ).value;

    if(name === ""){

        alert("Enter Name");
        return;
    }

    alert(
    "Message Sent Successfully!"
    );

    addNotification(
    "New Contact Message Received"
    );
}